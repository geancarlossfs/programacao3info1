<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 18/09/18
 * Time: 14:15
 */

defined('BASEPATH') OR exit('No direct script access allowed');

class Helloworld_model extends CI_Controller{

    public function __construct(){

        parent::__contruct();
        
        $this->load->model('helloworld_model');
    }

    public function index(){
        $data['result'] = $this->helloworld_model->getData();

        $this->load->view('helloworld_view', $data);
    }

}